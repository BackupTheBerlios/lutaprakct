#include <iostream>
#include <ctime>

#include "util/files/files.h"
#include "util/files/cfgfile.h"
#include "util/threads/threads.h"
#include "util/networking/server.h"
#include "util/networking/packetHandler.h"

int main(int argc, char **argv){
	
	net::Server server;
	net::PacketHandler netHandler;
	files::CfgFile CFG;
	
	std::cout << "Server Version 0.1" << std::endl;
#ifdef WORDS_BIGENDIAN
	std::cout << "Using Big Endian" << std::endl;
#endif
	std::cout << std::endl;
	
	if(!files::MakeDir("data")) {
		std::cerr << "Couldn't create data directory." << std::endl;
		return 0;
	}
	if(!files::MakeDir("info")) {
		std::cerr << "Couldn't create info directory." << std::endl;
		return EXIT_FAILURE;
	}
	
	try {
		srand(static_cast <unsigned> (time(0)) );
		unsigned int startTime = threads::Ticks();
		//CFG.open("server.cfg");
		server.initialize(5000);
		std::cout << "Initialization done, " << threads::Ticks() - startTime << " msec." << std::endl;
	} catch(errors::Exception& E) {
		std::cerr << "Exception during startup! " << E.getText() << std::endl;
		return 0;
	}
	
	while(1){
		try {
			server.checkConnections();
			server.checkPackets();
			if(!netHandler.handlePackets(server)) {
				threads::Delay(25);
			}
		} catch(errors::Exception& E) {
			std::cerr << E.getText() << std::endl;
		}
	}

	//shutdown
	try {
		std::cout << "Power down." << std::endl;
	} catch(errors::Exception& E) {
		std::cerr << "Exception during shutdown! " << E.getText() << std::endl;
		return EXIT_FAILURE;
	}
	return 1;	
}
